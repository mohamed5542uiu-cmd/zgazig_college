const search = document.getElementById('search');
const cards = [...document.querySelectorAll('.card')];

search.addEventListener('input', () => {
  const q = search.value.trim().toLowerCase();
  cards.forEach(card => {
    const text = (card.dataset.search + ' ' + card.innerText).toLowerCase();
    card.style.display = text.includes(q) ? '' : 'none';
  });
});

function showMessage(subject){
  alert('هنا هنضيف لاحقًا ملخصات ومحاضرات وامتحانات مادة: ' + subject);
}
